<?php 
include_once("connection.class.php");
class Accid{
 	var $conn;
 	function Accid(){
 		$this->conn=new Connection;
 	}
	function insert($table,$fields,$values){
		if($this->conn->connect()==true){
			return mysqli_query($this->conn->connection,
								"INSERT INTO ".$table." (".$fields.") 
								 VALUES (".$values.");");
		}
	}
	function getCount($table){
		if($this->conn->connect()==true){
			return mysqli_query($this->conn->connection,
								"SELECT COUNT(1) AS c FROM ".$table.";");
		}
	}
}
?>
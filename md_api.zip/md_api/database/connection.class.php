<?php 
class Connection {
    private $hostname;
    private $database;
    private $username;
    private $password;
    private $connection;

    public function __construct() {
        // Cambia estas credenciales según tu configuración local
        $this->hostname = "MySQL80";
        $this->database = "aacid"; // Cambia a tu base de datos local
        $this->username = "root"; // Cambia a tu usuario local
        $this->password = "Spartan661010+"; // Cambia a tu contraseña local
    }

    public function connect() {
        // Crear la conexión
        $this->connection = mysqli_connect($this->hostname, $this->username, $this->password, $this->database);
        
        // Verificar la conexión
        if (!$this->connection) {
            die("Error de conexión: " . mysqli_connect_error());
        }
        
        // Establecer el conjunto de caracteres a UTF-8
        mysqli_set_charset($this->connection, "utf8");

        return true;    
    }

    public function close() {
        if ($this->connection) {
            mysqli_close($this->connection);
        }
    }

    public function getConnection() {
        return $this->connection;
    }
}
?>

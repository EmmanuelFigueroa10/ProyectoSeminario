<?php
    // Ruta del directorio local
    $directory = "https://services1.arcgis.com/wV1kZW9z0MjamBP4/arcgis/rest/services/survey123_447c5e990761467ea867b2468af5af5d_results/FeatureServer/0/query";  // Cambia '/ruta_local' por la ruta de tu directorio local
    require($directory.'/database/moda.class.php');
    date_default_timezone_set("America/Guatemala");

    // Para usar file_get_contents
    ini_set("allow_url_fopen", 1);

    // Inicializa la clase Moda
    $moda = new Moda;

    // Para guardar los resultados
    $result = array();
    $result['success'] = false;
    $result['date'] = date('Y/m/d h:i:s');
    $save = true;

    // Variables necesarias para insertar
    $table = "data";
    $fields = "objectid,globalid,Depto,Muni,gestor,codigocaso,Tipovisita,Participantes,diavisita,horainicio,entrevista,causa,direccion,fuente,nombrecaso,TieneCUI,CUI,Edad,Sexo,Pueblo,Idioma,Diagnostico,TieneTelefono,Telefono,TieneCondiciones,ListaCongenitas,TieneDiscapacidad,ListaDiscapacidad,FactoresRiesgo,DetalleFactores,AccesoServicio,TieneSenalPeligro,ListaSenlpeligro,ListaAccionesPeligro,ProtocoloTx,ListaTratamiento,ListaTratamiento_other,AsistenciaAlimentaria,CuandoAsistencia,ListaAsistenciaAlim,ACF,Programas,ListaApoyo,ListaApoyo_other,Inscripcion,ListaInscripcion,ListaInscripcion_other,AccionSESAN,Listaaccionessesan,Listaaccionessesan_other,Respuesta_urgente,ListaAccionUrgente,Comentarios,Horafin,imgdisc,CreationDate,Creator,EditDate,Editor";
    $values = "";

    // Obtener los datos guardados por nodejs
    $json = file_get_contents($directory.'/json/fields.json');
    $fields = json_decode($json,true);
    $json = file_get_contents($directory.'/json/data.json');
    $data = json_decode($json,true);

    // Procesar el array de campos
    $field = "";
    $field_array = [];
    $i = 0;
    if ($fields) {
        foreach ($fields as $item) {
            $field_array[$i] = $item['name'];
            if ($i == 0) {
                $field .= $item['name'];
            } else {
                $field .= "," . $item['name'];
            }
            $i++;
        }
    }
    $fields = $field;
    $field_count = $i - 1;

    // Obtener cantidad de registros existentes
    $getCount = $moda->getCount($table);
    $old_count = 0;
    if ($getCount && mysqli_num_rows($getCount) > 0) {
        while ($row = mysqli_fetch_array($getCount)) {
            $old_count = $row['c'];
        }
    }

    // Obtener la cantidad de registros nuevos
    $new_count = count($data);

    // Eliminar registros antiguos del array
    $count = $new_count - $old_count;
    if ($count != 0) {
        array_splice($data, $count);
    }

    // Crear el array de valores
    $date_fields = array("diavisita", "Horafin", "CreationDate", "EditDate");
    $int_fields = array("Telefono");
    $value = "";
    $value_array = [];
    $i = 0;
    if ($data && $count != 0) {
        foreach ($data as $item) {
            $value = "";
            for ($c = 0; $c <= $field_count; $c++) {
                $val = $item['attributes'][$field_array[$c]];
                $tmp = str_replace(["'", "/", "ĺ", " ", "‐", "Ģ", "⁸"], ["", "|", "l", "", "-", "G", ""], $val);
                $val = $tmp;
                if (in_array($field_array[$c], $int_fields) && $val == '') {
                    $val = '0';
                }
                if ($c == 0) {
                    $value = "'".$val."'";
                } else {
                    $value .= ",'".$val."'";
                }
            }
            $value_array[$i] = $value;
            $i++;
        }
    }

    // Insertar todos los valores en la base de datos
    if ($count != 0) {
        for ($c = 0; $c < $count; $c++) {
            $values = $value_array[$c];
            if ($save) {
                $save = $moda->insert($table, $fields, $values);
            }
        }
        if ($save) {
            $result['data'] = "Cantidad de registros nuevos: $count";
            $result['success'] = true;
            $result['message'] = 'Información almacenada correctamente';
        } else {
            $result['data'] = "Cantidad de registros: $count";
            $result['success'] = false;
            $result['message'] = 'Error al guardar la información en la base de datos';
        }
    } else {
        $save = true;
        $result['data'] = "Cantidad de registros nuevos: $count";
        $result['success'] = true;
        $result['message'] = 'Los registros ya se encuentran actualizados';
    }

    $log = $result['date'] . "\n" . $result['message'] . "\n" . $result['data'] . "\n";
    $logfile = file_put_contents($directory.'/api.log', $log.PHP_EOL, FILE_APPEND | LOCK_EX);
?>

function moda(){
	/********* Global Variables **********/
	// Necessary links
	var url_feature_layer = 'https://services1.arcgis.com/wV1kZW9z0MjamBP4/arcgis/rest/services/survey123_447c5e990761467ea867b2468af5af5d_results/FeatureServer/0/query';
	var url_save = 'controllers/Accid/save.php';

	// Variables
	var records = 0; 				// Save the records count
	var record_count = 1000; 		// Quantity of records to get from de record <record_offset>
	var record_offset = 0; 			// Begin at the first record
	var array_fields = new Array();	// Array of field names
	var array_offset = new Array(); // Array of positions to get the <record_count> records
	var array_data = new Array(); 	// Array to save all fetched data
	var array_tmp1, array_tmp2; 	// Temporal arrays  for save data before merge with the <array_data>
	
	// Run
	getDetails();
	
	function getDetails(){
		// Get records quantity
		$.ajax({
			type: 'GET',
			async: false,
			url: url_feature_layer,
			data: { f: 'json', returnIdsOnly: 'true', returnCountOnly: 'true', where: '1=1', returnGeometry: 'false', spatialRel: 'esriSpatialRelIntersects', outFields: '*', cacheHint: 'true' },
			dataType: 'json',
			success: function(response){
				records = JSON.stringify(response.count);
				records = parseInt(records);
			},
			error: function(){
				alert("Error");
			}
		});
		// Get field names
		$.ajax({
			type: 'GET',
			async: false,
			url: url_feature_layer,
			data: { f: 'json', where: '1=1', returnGeometry: 'false', spatialRel: 'esriSpatialRelIntersects', outFields: '*', orderByFields: 'objectid ASC', resultOffset: '0', resultRecordCount: 0, cacheHint: 'true' },
			dataType: 'json',
			success: function(response){
				array_fields = response.fields;
				// console.log(array_fields);
				// Now get the data
				getData();
			},
			error: function(){
				alert("Error");
			}
		});
	}
	// Create array of offset points
	function setOffset(){
		while(record_offset <= records){
			array_offset.push(record_offset);
			record_offset = record_offset + record_count;
			if(record_offset > records){
				// console.log(array_offset);
			}
		}
	}
	function getData(){
		setOffset();
		$.each(array_offset, function(i,v) {
			record_offset = v;
			$.ajax({
				type: 'GET',
				async: false,
				url: url_feature_layer,
				data: { f: 'json', where: '1=1', returnGeometry: 'false', spatialRel: 'esriSpatialRelIntersects', outFields: '*', orderByFields: 'objectid DESC', resultOffset: record_offset, resultRecordCount: record_count, cacheHint: 'true' },
				dataType: 'json',
				success: function(response){
					array_tmp1 = array_data;
					array_tmp2 = response.features;
					array_data = array_tmp1.concat(array_tmp2);
					if((record_offset + record_count) > records){
						console.log(array_data);
						saveData();
					}
				},
				error: function(){
					alert("Error");
				}
			});
		});
	}
	function saveData(){
		var fields = JSON.stringify(array_fields);
		var data = JSON.stringify(array_data);
		$.ajax({
			type: 'POST',
			async: false,
			url: url_save,
			data: {'data': data, 'fields': fields},
			dataType: 'json',
			context: this,
			cache: false,
			success: function(response){
				if(response.success){
					console.log(response.message);
					console.log(response.data);
				}else{
					alert(response.message);
				}
			},
			error: function(){
				alert('No es posible guardar los datos.');
			}
		});
	}
}